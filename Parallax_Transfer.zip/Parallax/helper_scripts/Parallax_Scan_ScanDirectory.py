################################################
## e.g. Cooper
## Creates the initial ScanDB tables
################################################
'''
Pseudo Code:

Recursively grab all the files in the target directory and add them to the db

For each Filetype in Oracle_Filetypes
    Collect FileIDs with matching Filetype
    If there are any FileIDs
        Collect Indicators with matching Filetype
        For each FileID in FileIDs
            For each Indicator in Indicators
                Regex(FileID.Content, Indicator)
                    If positive, add Finding record
'''

########################
## Imports
########################
import os
from pathlib import Path
import re
import sqlite3
from sqlite3 import Error
import time

########################
## DB Querys
########################
def Write_Scan_File(conn, signature, relativePath, filetype):
    sql_cmd = ("INSERT INTO Files(Signature, RelativePath, Filetype) VALUES(" +
    "'" + str(signature) + "'," +
    "'" + str(relativePath) + "'," +
    "'" + str(filetype.lower()) + "'" +
    ");")
    
    conn.execute(sql_cmd)

def Write_Scan_Finding(conn, Signature, IndicatorID, FileID, LineNumber, LineText):
    # WARNING: All single quotes are removed from the LineText
    sql_cmd = ("INSERT INTO Findings(Signature, IndicatorID, FileID, LineNumber, LineText) VALUES(" +
    "'" + str(Signature) + "'," +
    "'" + str(IndicatorID) + "'," +
    "'" + str(FileID) + "'," +
    "'" + str(LineNumber) + "'," +
    "'" + str(LineText.replace("'", "")) + "'" +
    ");")
    
    conn.execute(sql_cmd)

def Get_Oracle_Filetypes(conn):
    sql_cmd = (
        ''' SELECT ID,FileExtension
            FROM Filetypes;
        '''
    )
    
    result = conn.execute(sql_cmd)
    return result.fetchall()
    
def Get_Scan_Files_By_FiletypeExtensions(conn, filetypeExtension):
    sql_cmd = (
        ''' SELECT ID,RelativePath
            FROM Files
            WHERE Files.Filetype=
        '''
    )
    sql_cmd += "'" + str(filetypeExtension) + "';"
    
    result = conn.execute(sql_cmd)
    return result.fetchall()
    
def Get_Oracle_Indicators_By_FiletypeIDs(conn, filetypeID):
    sql_cmd = (
        ''' SELECT Indicators.ID,Indicators.Indicator
            FROM Indicators,IndicatorFiletypes
            WHERE Indicators.ID=IndicatorFiletypes.IndicatorID
            AND IndicatorFiletypes.FiletypeID=
        '''
    )
    sql_cmd += "'" + str(filetypeID) + "';"
    
    result = conn.execute(sql_cmd)
    return result.fetchall()

########################
## Methods
########################
def create_connection(db_name):
    try:
        conn = sqlite3.connect('file:'+db_name+'?mode=rw', uri=True)
        conn.isolation_level = None        
        return conn
    except Error as e: 
        print(e)

def add_all_files_to_db(conn, directory):
    file_count = 0;
    result = list(Path(directory).rglob("*"))
    for file in result:
        file = str(file)        
        relative_top_level_base = os.path.basename(directory)
        
        signature = "none" # TODO Upgrade
        
        relativePath = file
        try:
            relativePath = relativePath[relativePath.index(relative_top_level_base)+len(relative_top_level_base)+1:]
        except:
            pass
        
        filetype = ""
        try:
            filetype = os.path.basename(file)
            filetype = file[file.rindex(".")+1:]
        except:
            pass
        
        file_count += 1
        Write_Scan_File(conn, signature, relativePath, filetype)
    
    return file_count
    
def scan_files(conn_scandb, directory):
    findings_count = 0;
    oracle_filetypes = Get_Oracle_Filetypes(conn_scandb)
    for filetype in oracle_filetypes:
        scan_files = Get_Scan_Files_By_FiletypeExtensions(conn_scandb, filetype[1])
        if len(scan_files) > 0:
            oracle_indicators = Get_Oracle_Indicators_By_FiletypeIDs(conn_scandb, filetype[0])
            if len(oracle_indicators) > 0:
                # At this point we have a list of files and list of possible indicators
                # Time so get the file text and start scanning for findings
                for file in scan_files:
                    filename = file[1]
                    filepath = os.path.join(directory, filename)
                    with open(filepath) as f:
                        content = f.readlines()
                    content = [x.strip() for x in content]
                    
                    lineNum = 1
                    for line in content:
                        for indicator in oracle_indicators:
                            query = re.search(indicator[1], line)
                            if query is not None:
                                # We found something, add it to the ScanDB    
                                findings_count += 1
                                
                                FindingSignature = "none" # TODO Upgrade
                                IndicatorID = indicator[0]
                                FileID = file[0]
                                LineNumber = lineNum
                                LineText = line
                                
                                Write_Scan_Finding(conn_scandb, FindingSignature, IndicatorID, FileID, LineNumber, LineText)
                        lineNum += 1
    return findings_count

def main_function(scan_db_name, target_directory):
    conn_scandb = create_connection(scan_db_name)
    
    
    t0 = time.time()
    
    file_count = add_all_files_to_db(conn_scandb, target_directory)
    
    t1 = time.time()
    seconds = "{:.2f}".format(t1-t0)
    print("Files: " + str(file_count) + ", Time: "  + seconds + " seconds")

    t0 = time.time()
    
    findings_count = scan_files(conn_scandb, target_directory)
    
    t1 = time.time()
    seconds = "{:.2f}".format(t1-t0)
    print("Susceptibilities: " + str(findings_count) + ", Time: "  + seconds + " seconds")
    
    # Close DB
    conn_scandb.commit()
    conn_scandb.close()

########################
## Start Here
########################
if __name__ == '__main__':
    pass
    