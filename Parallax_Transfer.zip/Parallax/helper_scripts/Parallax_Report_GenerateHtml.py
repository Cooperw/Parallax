################################################
## e.g. Cooper
## Generates a CSV from ScanDB
################################################

########################
## Imports
########################
import os
import sqlite3
from sqlite3 import Error

########################
## DB Querys
########################
def Get_Findings(conn):
    sql_cmd = (
        ''' SELECT Files.RelativePath,Findings.LineNumber,Indicators.CommonName,group_concat(DISTINCT CWEs.CWENumber),group_concat(DISTINCT CWEs.URL),group_concat(DISTINCT CWEs.ShortDescription)
            FROM Findings,Indicators,Files,IndicatorCWEs,CWEs
            WHERE Indicators.ID=Findings.IndicatorID
            AND Files.ID=Findings.FileID
            AND IndicatorCWEs.IndicatorID=Indicators.ID
            AND CWEs.ID=IndicatorCWEs.CWEID
            GROUP BY Findings.ID;
        '''
    )    
    
    result = conn.execute(sql_cmd)
    return result.fetchall()

########################
## Methods
########################
def create_connection(db_name):
    try:
        conn = sqlite3.connect('file:'+db_name+'?mode=rw', uri=True)
        conn.isolation_level = None        
        return conn
    except Error as e: 
        print(e)

def extract_and_write_auditedfindings(conn_scandb, outfile):
    pass

def extract_and_write_allfindings(conn_scandb, outfile):
    pass

def main_function(scan_db_name):
    conn_scandb = create_connection(scan_db_name)
    
    # Call functions
    outfile = scan_db_name + ".csv"
    try:
        outfile = outfile.replace(".db", "")
    except:
        pass
    extract_and_write_allfindings(conn_scandb, outfile)
    #extract_and_write_auditedfindings(conn_scandb, outfile)
    
    # Close DBs
    conn_scandb.close()

########################
## Start Here
########################
if __name__ == '__main__':
    pass
    