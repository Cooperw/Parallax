################################################
## e.g. Cooper
## Generates a CSV from ScanDB
################################################

########################
## Imports
########################
import csv
import os
import sqlite3
from sqlite3 import Error

########################
## DB Querys
########################
def Get_Findings(conn):
    sql_cmd = (
        ''' SELECT Files.RelativePath,Findings.LineNumber,Indicators.CommonName,group_concat(DISTINCT CWEs.CWENumber),group_concat(DISTINCT CWEs.URL),group_concat(DISTINCT CWEs.ShortDescription)
            FROM Findings,Indicators,Files,IndicatorCWEs,CWEs
            WHERE Indicators.ID=Findings.IndicatorID
            AND Files.ID=Findings.FileID
            AND IndicatorCWEs.IndicatorID=Indicators.ID
            AND CWEs.ID=IndicatorCWEs.CWEID
            GROUP BY Findings.ID;
        '''
    )    
    
    result = conn.execute(sql_cmd)
    return result.fetchall()

########################
## Methods
########################
def create_connection(db_name):
    try:
        conn = sqlite3.connect('file:'+db_name+'?mode=rw', uri=True)
        conn.isolation_level = None        
        return conn
    except Error as e: 
        print(e)

def extract_and_write_auditedfindings(conn_scandb, outfile):
    pass

def extract_and_write_allfindings(conn_scandb, outfile):
    with open(outfile, 'w', newline = '') as csv_file:
        csv_writer = csv.writer(csv_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        
        # Write headers
        csv_writer.writerow(["Path", "File", "LineNumber", "Indicator", "CWE", "CWE URL", "CWE Description"])
        
        # Fetch all findings
        findings = Get_Findings(conn_scandb)        
        
        for finding in findings:
            filepath = finding[0].replace('"', '')
            file_path_head, file_path_tail = os.path.split(filepath)
            
            lineNumber = finding[1].replace('"', '')
            indicator_commonname = finding[2].replace('"', '')
            cwe_num = finding[3].replace('"', '')
            cwe_url = finding[4].replace('"', '')
            cwe_desc = finding[5].replace('"', '')
            
            csv_writer.writerow([file_path_head, file_path_tail, lineNumber, indicator_commonname, cwe_num, cwe_url, cwe_desc])
        
        csv_file.close()

def main_function(scan_db_name):
    conn_scandb = create_connection(scan_db_name)
    
    # Call functions
    outfile = scan_db_name + ".csv"
    try:
        outfile = outfile.replace(".db", "")
    except:
        pass
    extract_and_write_allfindings(conn_scandb, outfile)
    #extract_and_write_auditedfindings(conn_scandb, outfile)
    
    # Close DBs
    conn_scandb.close()

########################
## Start Here
########################
if __name__ == '__main__':
    pass
    