################################################
## e.g. Cooper
## Generates Reports of a ScanDB
################################################

########################
## Imports
########################
import datetime; 
import os
import sqlite3
from sqlite3 import Error
import sys
import time

########################
## Dynamic Imports
########################
scripts_folder_name = 'report_scripts'
try:
    scripts_folder_relative = './'+scripts_folder_name
    sys.path.insert(1, scripts_folder_relative)
except:
    scripts_folder_relative = '.\\'+scripts_folder_name
    sys.path.insert(1, scripts_folder_relative)

import Parallax_Report_GenerateCSV

########################
## Misc Variables
########################
scan_db_name = ""

########################
## Start Here
########################

if __name__ == '__main__':
    try:
        scan_db_name = sys.argv[1]
    except:
        print("Usage: "+sys.argv[0]+" <scan db path>")
        quit(1)
    
    
    # Generate CSV
    Parallax_Report_GenerateCSV.main_function(scan_db_name)
