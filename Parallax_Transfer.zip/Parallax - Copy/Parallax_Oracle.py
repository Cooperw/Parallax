################################################
## e.g. Cooper
## Manages Construction of the default OracleDB
################################################

########################
## Imports
########################
import os
import sqlite3
from sqlite3 import Error
import sys

########################
## Dynamic Imports
########################
config_folder_name = 'oracle_scripts_configs'
try:
    config_folder_relative = './'+config_folder_name
    sys.path.insert(1, config_folder_relative)
except:
    config_folder_relative = '.\\'+config_folder_name
    sys.path.insert(1, config_folder_relative)

import Parallax_Oracle_CreateDatabase
import Parallax_Oracle_PopulateDefaults

########################
## Misc Variables
########################

oracle_db_name = ""

########################
## Start Here
########################

if __name__ == '__main__':
    try:
        oracle_db_name = sys.argv[1]
    except:
        print("Usage: "+sys.argv[0]+" <new db name>")
        quit(1)
    
    Parallax_Oracle_CreateDatabase.main_function(oracle_db_name)
    Parallax_Oracle_PopulateDefaults.main_function(oracle_db_name, config_folder_relative)
