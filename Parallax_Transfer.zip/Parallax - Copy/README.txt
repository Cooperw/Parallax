README

First Run Parallax_Oracle.py to setup basic scan configs
	Usage: Parallax_Oracle.py <new db name>

Then Run Parallax_Scan.py to scan a target directory
	Usage: Parallax_Scan.py <oracle db path> <target directory>

Then Run Parallax_Report.py to generate reports
	Usage: Parallax_Report.py <oracle db path> <scan db path>



Database Schemas

	OracleDB Schema
		Indicators
			ID (PK)
			CommonName
			Indicator

		Filetypes
			ID (PK)
			FileExtension

		IndicatorFiletypes
			ID (PK)
			IndicatorID (FK)
			FiletypeID (FK)

		CWEs
			ID (PK)
			CWENumber
			URL
			ShortDescription

		IndicatorCWEs
			ID (PK)
			IndicatorID (FK)
			CWEID (FK)



	ScanDB Schema

		Files
			ID (PK)
			Signature Hash(RelativePath)
			RelativePath
			Filetype

		Findings
			ID (PK)
			FindingSignature Hash(RelativePath+LineNumber+LineText)
			IndicatorID (FK)
			FileID (FK)
			LineNumber
			LineText

		Audits
			ID (PK)
			FindingID (FK)
			Positive
			Comments