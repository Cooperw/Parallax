################################################
## e.g. Cooper
## Generates a HTML Report from ScanDB
################################################

########################
## Imports
########################
import csv
from datetime import date
import json
import os
import sqlite3
from sqlite3 import Error
import time

########################
## Variables
########################
template_TEMPALTE_TEXT = "CHANGEME"
template_key_title = "python_title"
template_key_header_datetimestamp = "python_header_datetimestamp"
template_key_header_dbfile = "python_header_dbfile"
template_key_graph1_data_max_domain = "python_graph1_data_max_domain"
template_key_graph1_title = "python_graph1_title"
template_key_graph2_title = "python_graph2_title"
template_key_graph3_title = "python_graph3_title"
template_key_graph4_title = "python_graph4_title"
template_key_graph1_data = "python_graph1_data"
template_key_graph2_data = "python_graph2_data"
template_key_graph3_data = "python_graph3_data"
template_key_graph4_data = "python_graph4_data"
template_key_table1_data = "python_table1_data"

########################
## DB Querys
########################
def Get_Findings(conn):
    sql_cmd = (
        ''' SELECT Files.RelativePath,Findings.LineNumber,Indicators.CommonName,group_concat(DISTINCT CWEs.CWENumber),group_concat(DISTINCT CWEs.URL),group_concat(DISTINCT CWEs.ShortDescription)
            FROM Findings,Indicators,Files,IndicatorCWEs,CWEs
            WHERE Indicators.ID=Findings.IndicatorID
            AND Files.ID=Findings.FileID
            AND IndicatorCWEs.IndicatorID=Indicators.ID
            AND CWEs.ID=IndicatorCWEs.CWEID
            AND Findings.FalsePositive='0'
            GROUP BY Findings.ID;
        '''
    )    
    
    result = conn.execute(sql_cmd)
    return result.fetchall()
    
def Get_Findings_Count_By_File(conn):
    sql_cmd = (
        ''' SELECT Files.RelativePath, COUNT(*)
            FROM Findings,Indicators,Files,IndicatorCWEs,CWEs
            WHERE Indicators.ID=Findings.IndicatorID
            AND Files.ID=Findings.FileID
            AND IndicatorCWEs.IndicatorID=Indicators.ID
            AND CWEs.ID=IndicatorCWEs.CWEID
            AND Findings.FalsePositive='0'
            GROUP BY Files.RelativePath
            ORDER BY COUNT(*) DESC;
        '''
    )    
    
    result = conn.execute(sql_cmd)
    return result.fetchall()
    
def Get_Findings_Count_By_FilePath(conn, relative_path):
    sql_cmd = (
        ''' SELECT CWEs.CWENumber, COUNT(*)
            FROM Findings,Indicators,Files,IndicatorCWEs,CWEs
            WHERE Indicators.ID=Findings.IndicatorID
            AND Files.ID=Findings.FileID
            AND IndicatorCWEs.IndicatorID=Indicators.ID
            AND CWEs.ID=IndicatorCWEs.CWEID
            AND Findings.FalsePositive='0'
            AND Files.RelativePath='''
    )
    
    sql_cmd += "'" + relative_path + "'\n"
    sql_cmd += "GROUP BY CWEs.CWENumber;"
    
    result = conn.execute(sql_cmd)
    return result.fetchall()
    
def Get_FindingType_Count(conn):
    sql_cmd = (
        ''' SELECT CWEs.CWENumber,CWEs.URL,CWEs.ShortDescription, COUNT(*)
            FROM Findings,Indicators,Files,IndicatorCWEs,CWEs
            WHERE Indicators.ID=Findings.IndicatorID
            AND Files.ID=Findings.FileID
            AND IndicatorCWEs.IndicatorID=Indicators.ID
            AND CWEs.ID=IndicatorCWEs.CWEID
            AND Findings.FalsePositive='0'
            GROUP BY CWEs.CWENumber;
        '''
    )    
    
    result = conn.execute(sql_cmd)
    return result.fetchall()
    
def Get_FileType_Count(conn):
    sql_cmd = (
        ''' SELECT Files.Filetype,COUNT(*),Sum(Files.LineCount)
            FROM Files
            GROUP BY Files.Filetype;
        '''
    )    
    
    result = conn.execute(sql_cmd)
    return result.fetchall()

########################
## Methods
########################
def create_connection(db_name):
    try:
        conn = sqlite3.connect('file:'+db_name+'?mode=rw', uri=True)
        conn.isolation_level = None        
        return conn
    except Error as e: 
        print(e)

def GetKeySigniture(key):
    return 'id="'+key+'"'

def extract_and_write_findings(conn_scandb, out_filename, template_filename, scan_db_name):

    # Build graph data (build graph2 first for data lists)
    active_susceptibility_types = []
    
    # Graph2
    graph2_data = json.loads("{}")
    graph2_count = 0
    findings = Get_FindingType_Count(conn_scandb)
    for finding in findings:
        jkey = str(finding[0]) + ": " + str(finding[3])
        graph2_data[jkey] = finding[3]
        graph2_count += finding[3]
        
        # Attempt to add sus type to list of active suss
        if finding[0] not in active_susceptibility_types:
            active_susceptibility_types.append(finding[0])
    
    print(active_susceptibility_types)    
    
    # Graph1
    report_graph1_data_max_domain = 0
    findings = Get_Findings_Count_By_File(conn_scandb)
    graph1_top_findings = []
    count = 0
    while(len(graph1_top_findings) < 10 and len(graph1_top_findings) < len(findings)):
        print(findings[count])
        graph1_top_findings.append(findings[count])

        if report_graph1_data_max_domain < findings[count][1]:
            report_graph1_data_max_domain = findings[count][1]
        
        count += 1
    
    graph1_data = []
    row = ['group']
    for sus_type in active_susceptibility_types:
        row.append(sus_type)
    graph1_data.append(row)
    
    for finding in graph1_top_findings:
        sub_findings = Get_Findings_Count_By_FilePath(conn_scandb, finding[0])
    
        row = []
        
        base_filename = os.path.basename(finding[0])
        row.append(base_filename)
        
        
        for sus_type in active_susceptibility_types:
            sus_count_for_sub_finding = 0
            for sub_finding in sub_findings:
                if sub_finding[0] == sus_type:
                    sus_count_for_sub_finding = sub_finding[1]
            row.append(sus_count_for_sub_finding)
        print(row)
            
        
        print(finding)
        for sub_finding in sub_findings:
            print("\t"+str(sub_finding))
        graph1_data.append(row)
    print(graph1_data)
    
    # Graph3
    graph3_data = json.loads("{}")
    graph3_count = 0
    files = Get_FileType_Count(conn_scandb)
    for file in files:
        jkey = str(file[0]) + ": " + str(file[1])
        graph3_data[jkey] = file[1]
        graph3_count += file[1]

    # Graph4
    graph4_data = json.loads("{}")
    graph4_count = 0
    for file in files:
        jkey = str(file[0]) + ": " + str(file[2])
        graph4_data[jkey] = file[2]
        graph4_count += file[2]

    # Table1
    table1_data = json.loads("[]")
    allfindings = Get_Findings(conn_scandb)
    for finding in allfindings:
        print(finding)
        filepath = finding[0].replace('"', '')
        file_path_head, file_path_tail = os.path.split(filepath)
        
        lineNumber = finding[1].replace('"', '')
        indicator_commonname = finding[2].replace('"', '')
        cwe_num = finding[3].replace('"', '')
        cwe_url = finding[4].replace('"', '')
        cwe_desc = finding[5].replace('"', '')

        row_data = json.loads("{}")
        row_data["Path"] = file_path_head
        row_data["File"] = file_path_tail
        row_data["LineNumber"] = lineNumber
        row_data["Indicator"] = indicator_commonname
        row_data["Susceptibility"] = cwe_num
        
        table1_data.append(row_data)

    # Pull template data
    with open(template_filename) as template_file:
        template_content = template_file.readlines()
    
    # Write to report
    report_title = "Scan Report"
    report_header_datetimestamp = date.today().strftime("%m/%d/%y") + " " + time.strftime("%H:%M:%S %Z")
    report_header_dbfile = os.path.basename(scan_db_name)
    report_graph1_title = "Susceptibilities by Files (Top " + str(len(graph1_top_findings)) + ")"
    report_graph2_title = "Susceptibilities: " + str(graph2_count)
    report_graph3_title = "Files Scanned: " + str(graph3_count)
    report_graph4_title = "Total Lines: " + str(graph4_count)
    
    out_file = open(out_filename, "w")
    
    for line in template_content:
        if(GetKeySigniture(template_key_title) in line):
            line = line.replace(template_TEMPALTE_TEXT, report_title)
        if(GetKeySigniture(template_key_header_datetimestamp) in line):
            line = line.replace(template_TEMPALTE_TEXT, report_header_datetimestamp)
        if(GetKeySigniture(template_key_header_dbfile) in line):
            line = line.replace(template_TEMPALTE_TEXT, report_header_dbfile)
        if(GetKeySigniture(template_key_graph1_data_max_domain) in line):
            line = line.replace(template_TEMPALTE_TEXT, str(report_graph1_data_max_domain + 5))
        if(GetKeySigniture(template_key_graph1_title) in line):
            line = line.replace(template_TEMPALTE_TEXT, report_graph1_title)
        if(GetKeySigniture(template_key_graph2_title) in line):
            line = line.replace(template_TEMPALTE_TEXT, report_graph2_title)
        if(GetKeySigniture(template_key_graph3_title) in line):
            line = line.replace(template_TEMPALTE_TEXT, report_graph3_title)
        if(GetKeySigniture(template_key_graph4_title) in line):
            line = line.replace(template_TEMPALTE_TEXT, report_graph4_title)
        if(GetKeySigniture(template_key_graph1_data) in line):
            line = line.replace(template_TEMPALTE_TEXT, str(graph1_data).replace("'", '"'))
        if(GetKeySigniture(template_key_graph2_data) in line):
            line = line.replace(template_TEMPALTE_TEXT, str(graph2_data).replace("'", '"'))
        if(GetKeySigniture(template_key_graph3_data) in line):
            line = line.replace(template_TEMPALTE_TEXT, str(graph3_data).replace("'", '"'))
        if(GetKeySigniture(template_key_graph4_data) in line):
            line = line.replace(template_TEMPALTE_TEXT, str(graph4_data).replace("'", '"'))
        if(GetKeySigniture(template_key_table1_data) in line):
            line = line.replace(template_TEMPALTE_TEXT, str(table1_data).replace("'", '"'))
        
        out_file.write(line)
    
    out_file.close()

def main_function(scan_db_name, template_filename):
    conn_scandb = create_connection(scan_db_name)
    
    # Call functions
    outfile = scan_db_name + ".html"
    try:
        outfile = outfile.replace(".db", "")
    except:
        pass
    extract_and_write_findings(conn_scandb, outfile, template_filename, scan_db_name)
    
    # Close DBs
    conn_scandb.close()

########################
## Start Here
########################
if __name__ == '__main__':
    pass
    