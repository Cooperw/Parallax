################################################
## e.g. Cooper
## Creates the initial ScanDB tables
################################################

########################
## Imports
########################
import os.path
from os import path
import shutil
import sqlite3
from sqlite3 import Error

########################
## Create Statements
########################
# add back unique Signature
sql_create_table_Files = (
    ''' CREATE TABLE IF NOT EXISTS Files (
        ID integer PRIMARY KEY,
        Signature text NOT NULL UNIQUE,
        RelativePath text NOT NULL UNIQUE,
        Filetype text,
        LineCount integer NOT NULL
    ); '''
)

# add back unique FindingSignature
sql_create_table_Findings = (
    ''' CREATE TABLE IF NOT EXISTS Findings (
        ID integer PRIMARY KEY,
        Signature text NOT NULL UNIQUE,
        IndicatorID integer NOT NULL,
        FileID integer NOT NULL,
        LineNumber text NOT NULL,
        LineText text NOT NULL,
        FirstSeenDTS text NOT NULL,
        LastSeenDTS text NOT NULL,
        StatusCode integer NOT NULL,
        StatusCodeDTS text NOT NULL, 
        Comments text,        
        FOREIGN KEY (IndicatorID) REFERENCES Indicators (ID),
        FOREIGN KEY (FileID) REFERENCES Files (ID)
    ); '''
)

########################
## Methods
########################
def db_exists(db_name):
    return path.exists(db_name)

def copy_oracle(oracledb_name, scandb_name):
    shutil.copyfile(oracledb_name, scandb_name)
    
def create_connection(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file)

        if conn is not None:
            conn.execute(sql_create_table_Files)
            conn.execute(sql_create_table_Findings)
    except Error as e: 
        print(e)
    finally:
        if conn:
            conn.close()

def main_function(oracledb_name, scandb_name):
    if not db_exists(scandb_name):
        copy_oracle(oracledb_name, scandb_name)
    create_connection(scandb_name)

########################
## Start Here
########################
if __name__ == '__main__':
    pass
    