################################################
## e.g. Cooper
## Creates the initial OracleDB tables
################################################

########################
## Imports
########################
import sqlite3
from sqlite3 import Error

########################
## Create Statements
########################
sql_create_table_Indicators = (
    ''' CREATE TABLE IF NOT EXISTS Indicators (
        ID integer PRIMARY KEY,
        CommonName text NOT NULL,
        Indicator text NOT NULL
    ); '''
)

sql_create_table_Filetypes = (
    ''' CREATE TABLE IF NOT EXISTS Filetypes (
        ID integer PRIMARY KEY,
        FileExtension text NOT NULL UNIQUE
    ); '''
)

sql_create_table_IndicatorFiletypes = (
    ''' CREATE TABLE IF NOT EXISTS IndicatorFiletypes (
        ID integer PRIMARY KEY,
        IndicatorID integer NOT NULL,
        FiletypeID integer NOT NULL,
        FOREIGN KEY (IndicatorID) REFERENCES Indicators (ID),
        FOREIGN KEY (FiletypeID) REFERENCES Filetypes (ID)
    ); '''
)

sql_create_table_CWEs = (
    ''' CREATE TABLE IF NOT EXISTS CWEs (
        ID integer PRIMARY KEY,
        CWENumber text NOT NULL UNIQUE,
        URL text,
        ShortDescription text
    ); '''
)

sql_create_table_IndicatorCWEs = (
    ''' CREATE TABLE IF NOT EXISTS IndicatorCWEs (
        ID integer PRIMARY KEY,
        IndicatorID integer NOT NULL,
        CWEID integer NOT NULL,
        FOREIGN KEY (IndicatorID) REFERENCES Indicators (ID),
        FOREIGN KEY (CWEID) REFERENCES CWEs (ID)
    ); '''
)

########################
## Methods
########################
def create_connection(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file)

        if conn is not None:
            conn.execute(sql_create_table_Indicators)
            conn.execute(sql_create_table_Filetypes)
            conn.execute(sql_create_table_IndicatorFiletypes)
            conn.execute(sql_create_table_CWEs)
            conn.execute(sql_create_table_IndicatorCWEs)
    except Error as e: 
        print(e)
    finally:
        if conn:
            conn.close()

def main_function(db_name):
    create_connection(db_name)

########################
## Start Here
########################
if __name__ == '__main__':
    pass
    