################################################
## e.g. Cooper
## Manages Scanning of a directory
################################################

########################
## Imports
########################
import datetime; 
import os
import sqlite3
from sqlite3 import Error
import sys
import time

########################
## Dynamic Imports
########################
scripts_folder_name = 'scan_scripts'
try:
    scripts_folder_relative = './'+scripts_folder_name
    sys.path.insert(1, scripts_folder_relative)
except:
    scripts_folder_relative = '.\\'+scripts_folder_name
    sys.path.insert(1, scripts_folder_relative)

import Parallax_Scan_CreateDatabase
import Parallax_Scan_ScanDirectory

########################
## Misc Variables
########################

oracle_db_name = ""
target_directory = ""

########################
## Start Here
########################

if __name__ == '__main__':
    try:
        oracle_db_name = sys.argv[1]
        target_directory = sys.argv[2]
    except:
        print("Usage: "+sys.argv[0]+" <oracle db path> <target directory>")
        quit(1)
    
    abs_directory = os.path.abspath(target_directory)
    dir_name = os.path.basename(abs_directory)
    timestamp = str(datetime.datetime.now().timestamp())
    timestamp = timestamp[:timestamp.index('.')]
    scan_db_name = dir_name + "_" + timestamp + ".db"
    
    t0 = time.time()
    
    # Create ScanDB
    Parallax_Scan_CreateDatabase.main_function(scan_db_name)
    
    # Scan Directory
    Parallax_Scan_ScanDirectory.main_function(oracle_db_name, scan_db_name, abs_directory)
    
    t1 = time.time()
    print("Total Scan Time: "+str(t1-t0))
