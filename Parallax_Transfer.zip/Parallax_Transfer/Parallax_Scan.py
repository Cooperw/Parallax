################################################
## e.g. Cooper
## Manages Scanning of a directory
################################################

########################
## Imports
########################
import datetime; 
import os
import sqlite3
from sqlite3 import Error
import sys
import time

########################
## Misc Variables
########################
oracle_db_name = ""
target_directory = ""

output_folder_name = 'output'
scripts_folder_name = 'helper_scripts'

########################
## Dynamic Imports
########################
try:
    scripts_folder_relative = './'+scripts_folder_name
    sys.path.insert(1, scripts_folder_relative)
except:
    scripts_folder_relative = '.\\'+scripts_folder_name
    sys.path.insert(1, scripts_folder_relative)

import Parallax_Scan_CreateDatabase
import Parallax_Scan_ScanDirectory

########################
## Methods
########################
def output_path(base_filename):
    return os.path.join(output_folder_name, base_filename)
    
def main_function():
    abs_directory = os.path.abspath(target_directory)
    dir_name = os.path.basename(abs_directory)
    #timestamp = str(datetime.datetime.now().timestamp()) # old, prior to multirun
    #timestamp = timestamp[:timestamp.index('.')] # old, prior to multirun
    #scan_db_name = dir_name + "_" + timestamp + ".db" # old, prior to multirun
    scan_db_name = dir_name + ".db"
    
    t0 = time.time()
    
    # Create ScanDB
    Parallax_Scan_CreateDatabase.main_function(output_path(oracle_db_name), output_path(scan_db_name))
    
    # Scan Directory
    Parallax_Scan_ScanDirectory.main_function(output_path(scan_db_name), abs_directory)
    
    t1 = time.time()
    seconds = "{:.2f}".format(t1-t0)
    print("Total Scan Time: " + seconds + " seconds")
    
    print("ScanDB File: " + output_path(scan_db_name))
    
    return scan_db_name
    

def main_callable(_oracle_db_name, _target_directory):
    global oracle_db_name
    global target_directory
    
    oracle_db_name = _oracle_db_name
    target_directory = _target_directory
    
    return main_function()

########################
## Start Here
########################
if __name__ == '__main__':
    try:
        oracle_db_name = sys.argv[1]
        target_directory = sys.argv[2]
    except:
        print("Usage: "+sys.argv[0]+" <oracle db path> <target directory>")
        quit(1)
    
    main_function()
