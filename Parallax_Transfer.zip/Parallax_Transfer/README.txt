README

Author: Cooper
Inspired by: Gene


Quick Start (Runs all phases):
	Usage: python3 Parallax.py <target directory>
	Output: ScanDB.db, ScanDB_Report.csv, ScanDB_Report.html

Parallax is broken into 3 phases and each phase can be run individually:

	Parallax_Oracle.py
		The Oracle step generates a template database populated with configs, scan indicators, CWE data, etc.
		Usage: python3 Parallax_Oracle.py <new oracle db name>
		Output: OracleDB file
		
	Parallax_Scan.py
		The Scan step copies the templated Oracle data to a fresh database and then actually performs the scans on the target directory
		Usage: python3 Parallax_Scan.py <oracle db path> <target directory>
		Output: ScanDB file
		
	Parallax_Report.py
		The Report step uses the ScanDB to generate various reports like CVS exports and HTML reports.
		Usage: python3 Parallax_Report.py <scan db path>
		Output: ScanDB_Report.csv, ScanDB_Report.html

The Parallax ScanDB can be directly interfaced with using SQLite3 and the database schema found in README_SCHEMA.txt for further analysis.

*Output names will vary with specified target directory