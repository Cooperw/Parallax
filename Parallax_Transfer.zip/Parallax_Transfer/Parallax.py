################################################
## e.g. Cooper
## Executes all Parallax phases with one command
################################################

########################
## Imports
########################
import os
import sqlite3
from sqlite3 import Error
import sys

import Parallax_Oracle
import Parallax_Scan
import Parallax_Report

########################
## Misc Variables
########################
target_directory = ""

output_folder_name = 'output'

########################
## Methods
########################
def output_path(base_filename):
    return os.path.join(output_folder_name, base_filename)

########################
## Start Here
########################
if __name__ == '__main__':
    try:
        target_directory = sys.argv[1]
    except:
        print("Usage: "+sys.argv[0]+" <target directory>")
        quit(1)
    
    oracle_db_name = "oracle.db"
    Parallax_Oracle.main_callable(oracle_db_name)
    scan_db_name = Parallax_Scan.main_callable(oracle_db_name, target_directory)
    Parallax_Report.main_callable(scan_db_name)
    
    # cleanup and remove oracledb
    os.remove(output_path(oracle_db_name))
