################################################
## e.g. Cooper
## Populates the OracleDB tables with various config files
##
## Config file structure:
##  data1.1,data1.2,data1.3
##  data2.1,data2.2,data2.3
##  data3.1,data3.2,data3.3
##  ...
################################################

########################
## Imports
########################
import os
import sqlite3
from sqlite3 import Error

########################
## Misc Variables
########################
# Table Names
config_indicators_tablename = "Indicators"
config_filetypes_tablename = "Filetypes"
config_cwes_tablename = "CWEs"
config_links_indicators_filetypes_tablename = "IndicatorFiletypes"
config_links_indicators_cwes_tablename = "IndicatorCWEs"

# Table Headers
config_indicators_tableheader = ['CommonName', 'Indicator']
config_filetypes_tableheader = ['FileExtension']
config_cwes_tableheader = ['CWENumber', 'URL', 'ShortDescription']
config_links_indicators_filetypes_tableheader = ['IndicatorID', 'FiletypeID']
config_links_indicators_cwes_tableheader = ['IndicatorID', 'CWEID']

# Filenames
config_indicators_filename = "initial_indicators.config"
config_filetypes_filename = "initial_filetypes.config"
config_cwes_filename = "initial_cwes.config"
config_links_indicators_filetypes_filename = "initial_links_indicators_filetypes.config"
config_links_indicators_cwes_filename = "initial_links_indicators_cwes.config"

########################
## Methods
########################
def create_connection(db_name):
    try:
        conn = sqlite3.connect('file:'+db_name+'?mode=rw', uri=True)
        conn.isolation_level = None        
        return conn
    except Error as e: 
        print(e)

def clean_relative_path(folder, filename):
    return os.path.join(folder, filename)

def read_and_import_config(conn, table_name, table_header, filename):
    with open(filename) as f:
        content = f.readlines()
    content = [x.strip() for x in content]
    
    columns_str = ", ".join(table_header) # join to formatted string
    
    for line in content:
        data = line.split(',') # split into fields
        data_str = "', '".join(data) # rejoin to formatted string
        data_str = "'" + data_str + "'" # add end caps
        
        # build and execute INSERT
        sql_cmd = ('INSERT INTO ' + 
        table_name + "(" + columns_str + ") " +
        "VALUES(" + data_str + ");")
        
        #cur = conn.cursor()
        conn.execute(sql_cmd)

def fetch_PK_by_name(conn, table_name, search_column, search_phrase):
    sql_cmd = "SELECT ID FROM "+table_name+" WHERE "+search_column+" LIKE '"+search_phrase+"';"
    result = conn.execute(sql_cmd)
    return result.fetchall()

def read_and_import_links(conn, table_name, table_header, filename, fk1_table_name, fk1_search_column, fk2_table_name, fk2_search_column):
    with open(filename) as f:
        content = f.readlines()
    content = [x.strip() for x in content]
    
    columns_str = ", ".join(table_header) # join to formatted string
    
    for line in content:
        data = line.split(',') # split into fields
        
        # Fetch Keys, there can be multiple signitures and indicators so you must do multilevel linking
        fk1_ids = fetch_PK_by_name(conn, fk1_table_name, fk1_search_column, data[0])
        fk2_ids = fetch_PK_by_name(conn, fk2_table_name, fk2_search_column, data[1])
        
        for fk1_id in fk1_ids:
            for fk2_id in fk2_ids:                
                # assemble data values string
                data_str = str(fk1_id[0]) + ", " + str(fk2_id[0])
                
                # build and execute INSERT
                sql_cmd = ('INSERT INTO ' + 
                table_name + "(" + columns_str + ") " +
                "VALUES(" + data_str + ");")
                
                conn.execute(sql_cmd)

def populate_db(conn, relative_path):
    if conn is not None:
        read_and_import_config(conn, config_indicators_tablename, config_indicators_tableheader,
        clean_relative_path(relative_path, config_indicators_filename))
        
        read_and_import_config(conn, config_filetypes_tablename, config_filetypes_tableheader,
        clean_relative_path(relative_path, config_filetypes_filename))
        
        read_and_import_config(conn, config_cwes_tablename, config_cwes_tableheader,
        clean_relative_path(relative_path, config_cwes_filename))
        
        # Build ForeignKey Linkage        
        # link indicators and filetypes
        read_and_import_links(
        conn, config_links_indicators_filetypes_tablename, config_links_indicators_filetypes_tableheader,
        clean_relative_path(relative_path, config_links_indicators_filetypes_filename),
        config_indicators_tablename, "CommonName",
        config_filetypes_tablename, "FileExtension")
        # link indicators and cwes
        read_and_import_links(
        conn, config_links_indicators_cwes_tablename, config_links_indicators_cwes_tableheader, 
        clean_relative_path(relative_path, config_links_indicators_cwes_filename),
        config_indicators_tablename, "CommonName",
        config_cwes_tablename, "CWENumber")

def main_function(db_name, relative_path):
    conn = create_connection(db_name)
    
    populate_db(conn, relative_path)
    
    conn.commit()
    conn.close()

########################
## Start Here
########################
if __name__ == '__main__':
    pass
    