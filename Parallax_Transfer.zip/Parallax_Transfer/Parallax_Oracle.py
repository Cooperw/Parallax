################################################
## e.g. Cooper
## Manages Construction of the default OracleDB
################################################

########################
## Imports
########################
import os
import sqlite3
from sqlite3 import Error
import sys

########################
## Misc Variables
########################
oracle_db_name = ""

output_folder_name = 'output'
scripts_folder_name = 'helper_scripts'
configs_folder_name = 'configs'

########################
## Dynamic Imports
########################
try:
    scripts_folder_relative = './'+scripts_folder_name
    sys.path.insert(1, scripts_folder_relative)
except:
    scripts_folder_relative = '.\\'+scripts_folder_name
    sys.path.insert(1, scripts_folder_relative)

import Parallax_Oracle_CreateDatabase
import Parallax_Oracle_PopulateDefaults

########################
## Methods
########################
def output_path(base_filename):
    return os.path.join(output_folder_name, base_filename)

def main_function():
    Parallax_Oracle_CreateDatabase.main_function(output_path(oracle_db_name))
    Parallax_Oracle_PopulateDefaults.main_function(output_path(oracle_db_name), configs_folder_name)    

def main_callable(_oracle_db_name):
    global oracle_db_name
    oracle_db_name = _oracle_db_name
    
    return main_function()

########################
## Start Here
########################
if __name__ == '__main__':
    try:
        oracle_db_name = sys.argv[1]
    except:
        print("Usage: "+sys.argv[0]+" <new db name>")
        quit(1)
    
    main_function()
