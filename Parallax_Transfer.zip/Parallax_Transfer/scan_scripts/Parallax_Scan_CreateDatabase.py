################################################
## e.g. Cooper
## Creates the initial ScanDB tables
################################################

########################
## Imports
########################
import sqlite3
from sqlite3 import Error

########################
## Create Statements
########################
# add back unique Signature
sql_create_table_Files = (
    ''' CREATE TABLE IF NOT EXISTS Files (
        ID integer PRIMARY KEY,
        Signature text NOT NULL,
        RelativePath text NOT NULL UNIQUE,
        Filetype text
    ); '''
)

# add back unique FindingSignature
sql_create_table_Findings = (
    ''' CREATE TABLE IF NOT EXISTS Findings (
        ID integer PRIMARY KEY,
        Signature text NOT NULL,
        IndicatorID integer NOT NULL,
        FileID integer NOT NULL,
        LineNumber text NOT NULL,
        LineText text NOT NULL,
        FOREIGN KEY (IndicatorID) REFERENCES Indicators (ID),
        FOREIGN KEY (FileID) REFERENCES Files (ID)
    ); '''
)

sql_create_table_Audits = (
    ''' CREATE TABLE IF NOT EXISTS Audits (
        ID integer PRIMARY KEY,
        FindingID integer NOT NULL,
        Positive text NOT NULL,
        Comments text NOT NULL,
        FOREIGN KEY (FindingID) REFERENCES Findings (ID)
    ); '''
)

########################
## Methods
########################
def create_connection(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file)

        if conn is not None:
            conn.execute(sql_create_table_Files)
            conn.execute(sql_create_table_Findings)
            conn.execute(sql_create_table_Audits)
    except Error as e: 
        print(e)
    finally:
        if conn:
            conn.close()

def main_function(db_name):
    create_connection(db_name)

########################
## Start Here
########################
if __name__ == '__main__':
    pass
    