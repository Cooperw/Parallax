There are two types of SQLite3 Databases used in Parallax.
The first known as the OracleDB is generated as a template and then copied for each run into a ScanDB.
The ScanDB includes templated OracleDB plus additional tables for findings, files, etc.

Database Schemas

	OracleDB Schema (Generated Template)
		Indicators
			ID (PK)
			CommonName
			Indicator

		Filetypes
			ID (PK)
			FileExtension

		IndicatorFiletypes
			ID (PK)
			IndicatorID (FK)
			FiletypeID (FK)

		CWEs
			ID (PK)
			CWENumber
			URL
			ShortDescription

		IndicatorCWEs
			ID (PK)
			IndicatorID (FK)
			CWEID (FK)



	ScanDB Schema (Also includes OracleDB Tables)
		
		Files
			ID (PK)
			Signature Hash(RelativePath)
			RelativePath
			Filetype
			LineCount

		Findings
			ID (PK)
			FindingSignature Hash(RelativePath+LineNumber+LineText)
			IndicatorID (FK)
			FileID (FK)
			LineNumber
			LineText
			FalsePositive