################################################
## e.g. Cooper
## Generates Reports of a ScanDB
################################################

########################
## Imports
########################
import datetime; 
import os
import sqlite3
from sqlite3 import Error
import sys
import time

########################
## Misc Variables
########################
scan_db_name = ""
template_filename = "template.html"

output_folder_name = 'output'
scripts_folder_name = 'helper_scripts'
config_folder_name = 'configs'

########################
## Dynamic Imports
########################
try:
    scripts_folder_relative = './'+scripts_folder_name
    sys.path.insert(1, scripts_folder_relative)
except:
    scripts_folder_relative = '.\\'+scripts_folder_name
    sys.path.insert(1, scripts_folder_relative)

import Parallax_Report_GenerateCSV
import Parallax_Report_GenerateHtml

########################
## Methods
########################
def output_path(base_filename):
    return os.path.join(output_folder_name, base_filename)
    
def config_path(base_filename):
    return os.path.join(config_folder_name, base_filename)
    
def main_function():
    # Generate CSV
    Parallax_Report_GenerateCSV.main_function(output_path(scan_db_name))
    
    # Generate HTML
    Parallax_Report_GenerateHtml.main_function(output_path(scan_db_name), config_path(template_filename))

def main_callable(_scan_db_name):
    global scan_db_name
    
    scan_db_name = _scan_db_name
    
    return main_function()

########################
## Start Here
########################
if __name__ == '__main__':
    try:
        scan_db_name = sys.argv[1]
    except:
        print("Usage: "+sys.argv[0]+" <scan db path>")
        quit(1)
    
    main_function()
